
    (function() {
      var preconnectOrigins = ["https://cdn.shopify.com","https://extensions.shopifycdn.com"];
      var scripts = ["/cdn/shopifycloud/checkout-web/assets/c1/polyfills.C7jITNoQ.js","/cdn/shopifycloud/checkout-web/assets/c1/app.Dyy22ipq.js","/cdn/shopifycloud/checkout-web/assets/c1/esnext-vendor.a_XaC4HL.js","/cdn/shopifycloud/checkout-web/assets/c1/context-browser.D437MbUA.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPayExternalAppContext.C-Iw67BE.js","/cdn/shopifycloud/checkout-web/assets/c1/addresses-mailing-address.G7cqzrO6.js","/cdn/shopifycloud/checkout-web/assets/c1/Title.C_Yvyftj.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useShopPayCheckoutGqlVersion.CKznM0N1.js","/cdn/shopifycloud/checkout-web/assets/c1/utils-shopId.C4pbg2T0.js","/cdn/shopifycloud/checkout-web/assets/c1/payment-methods-filterAvailableMethods.DVgHJKd8.js","/cdn/shopifycloud/checkout-web/assets/c1/shop-pay-normalizeBuyerDetails.Da8_tkCh.js","/cdn/shopifycloud/checkout-web/assets/c1/graphql-UserPrivacySettingsSetMutation.D3asDelq.js","/cdn/shopifycloud/checkout-web/assets/c1/utils-getCommonShopPayExternalTelemetryAttributes.BUL-X4rW.js","/cdn/shopifycloud/checkout-web/assets/c1/extensions-rpc.C1QJxTa1.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useUnauthenticatedErrorModal.DnxI-G0K.js","/cdn/shopifycloud/checkout-web/assets/c1/hydrate.B3iUOdvs.js","/cdn/shopifycloud/checkout-web/assets/c1/locale-en.CwVOIXbB.js","/cdn/shopifycloud/checkout-web/assets/c1/page-OnePage.C8FAAvto.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useWalletsTimeout.nW2JS4eW.js","/cdn/shopifycloud/checkout-web/assets/c1/MarketsProDisclaimer.BQYvO9fA.js","/cdn/shopifycloud/checkout-web/assets/c1/remember-me-hooks.BUq8fVEr.js","/cdn/shopifycloud/checkout-web/assets/c1/color-contrast-colorContrast.BENZdk0C.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useHasOrdersFromMultipleShops.BjPQcEkb.js","/cdn/shopifycloud/checkout-web/assets/c1/OffsitePaymentFailed.C-nILne-.js","/cdn/shopifycloud/checkout-web/assets/c1/NoAddressLocationFullDetour.r4OCGiZ-.js","/cdn/shopifycloud/checkout-web/assets/c1/components-DeliveryTransition.CGc-40UP.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useGeneralPaymentErrorMessage.BlPgn80s.js","/cdn/shopifycloud/checkout-web/assets/c1/ChangeCompanyLocationLink.098V-dHs.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useStableHostMethodsReferences.BZTEr9U9.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useSandboxTelemetry.CcgKD_T_.js","/cdn/shopifycloud/checkout-web/assets/c1/BillingAddressForm.CrKm6MRP.js","/cdn/shopifycloud/checkout-web/assets/c1/PhoneField.BxJV8mgc.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useFormattedPhoneNumber.DqDcXYkU.js","/cdn/shopifycloud/checkout-web/assets/c1/EmptyState.C14S-v3t.js","/cdn/shopifycloud/checkout-web/assets/c1/Choice.DB7ZJpXw.js","/cdn/shopifycloud/checkout-web/assets/c1/Checkbox.CKgT6RzQ.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-usePostPurchase.DfPNXxI3.js","/cdn/shopifycloud/checkout-web/assets/c1/Interaction-tracker.DNfRuDET.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useCanChangeCompanyLocation.B8ajJ4If.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useForceShopPayUrl.B45Ql6vC.js","/cdn/shopifycloud/checkout-web/assets/c1/ShopPayLogo.DnKgRY1d.js","/cdn/shopifycloud/checkout-web/assets/c1/AutocompleteField-hooks.edFPJ3VF.js","/cdn/shopifycloud/checkout-web/assets/c1/PendingShipping.DgRX08n7.js","/cdn/shopifycloud/checkout-web/assets/c1/ImpressionEventCapture.BuGpnAlc.js","/cdn/shopifycloud/checkout-web/assets/c1/StoreCreditRedemption-StoreCreditRedemptionErrorBanner.BxJhiQDC.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentIcon.DXMlN58j.js","/cdn/shopifycloud/checkout-web/assets/c1/shop-cash-context.7QVAx-ON.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentLine.DBmqEDx_.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useShopPayProgressIntercepts.CtLFpugN.js","/cdn/shopifycloud/checkout-web/assets/c1/billing-address-hooks.C3c9FiXS.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useShowShopPayOptin.DZGJ4tc2.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useUpdateCheckoutAddress.Bxk9pSZy.js","/cdn/shopifycloud/checkout-web/assets/c1/Section.YB4d3R1W.js","/cdn/shopifycloud/checkout-web/assets/c1/useShopPaySessionTokenStorage.BLvMna4H.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useOnePageFormSubmit.BHYNMsXz.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentButtons.Ka2IQaBz.js","/cdn/shopifycloud/checkout-web/assets/c1/utilities-shop-pay-alternative-payment-flow.D_SAWQJH.js","/cdn/shopifycloud/checkout-web/assets/c1/shop-cash-monorail.B7zt-G50.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-useAvailableShopPromotionDiscount.BnTyrSk_.js","/cdn/shopifycloud/checkout-web/assets/c1/BillingAddressSelector.QFMmi7lc.js","/cdn/shopifycloud/checkout-web/assets/c1/PaymentErrorBanner.C3pZOQP1.js","/cdn/shopifycloud/checkout-web/assets/c1/Switch.BpZOv1Nq.js","/cdn/shopifycloud/checkout-web/assets/c1/shipping-rates-progressiveShippingRatesLoading.DSxs78CI.js","/cdn/shopifycloud/checkout-web/assets/c1/ShipmentBreakdown.DZr6YxEc.js","/cdn/shopifycloud/checkout-web/assets/c1/MerchandiseModal.DIMH0M0M.js","/cdn/shopifycloud/checkout-web/assets/c1/extension-targets-shipping-options.BraWyCW_.js","/cdn/shopifycloud/checkout-web/assets/c1/EstimatedDeliveryContent.BItORP3j.js","/cdn/shopifycloud/checkout-web/assets/c1/ShippingMethodRateLabel.C2b0QbJp.js","/cdn/shopifycloud/checkout-web/assets/c1/StackedMerchandisePreview.Z4xulKS8.js","/cdn/shopifycloud/checkout-web/assets/c1/ShippingMethodSelector.M95XaNJm.js","/cdn/shopifycloud/checkout-web/assets/c1/TextArea.CiP50HHP.js","/cdn/shopifycloud/checkout-web/assets/c1/SubscriptionPriceBreakdown.CGPyzE3M.js","/cdn/shopifycloud/checkout-web/assets/c1/hooks-usePaypalRowEffects.1Fph7ll-.js","/cdn/shopifycloud/checkout-web/assets/c1/Middot.DZ9ftJfj.js","/cdn/shopifycloud/checkout-web/assets/c1/ShippingGroupsSummaryLine.B4Be2Z1I.js","/cdn/shopifycloud/checkout-web/assets/c1/StockProblems-StockProblemsLineItemList.n9c-8XRi.js","/cdn/shopifycloud/checkout-web/assets/c1/utilities-publishMessage.BCoHv-Yl.js","/cdn/shopifycloud/checkout-web/assets/c1/component-RuntimeExtension.Dvb2dVSr.js","/cdn/shopifycloud/checkout-web/assets/c1/AnnouncementRuntimeExtensions.Beosdwh5.js","/cdn/shopifycloud/checkout-web/assets/c1/QRCode.CXIEH4oK.js","/cdn/shopifycloud/checkout-web/assets/c1/utilities-dates.ChO2GdxN.js","/cdn/shopifycloud/checkout-web/assets/c1/NumberField.BCw2WVNQ.js","/cdn/shopifycloud/checkout-web/assets/c1/extensions-remote-dom.oED0xIwI.js","/cdn/shopifycloud/checkout-web/assets/c1/Sheet.CGdadG8_.js","/cdn/shopifycloud/checkout-web/assets/c1/utilities-use-extension-skeletons.kMHagyc4.js","/cdn/shopifycloud/checkout-web/assets/c1/ExtensionsInner.BkqeRbPH.js","/cdn/shopifycloud/checkout-web/assets/c1/adapter-host.iCTOXKyW.js","/cdn/shopifycloud/checkout-web/assets/c1/sandbox.BNMWqM3S.worker.js","/cdn/shopifycloud/checkout-web/assets/c1/sandbox-2025-07.BU1xQJiP.worker.js","https://extensions.shopifycdn.com/shopifycloud/checkout-web/assets/c1/polyfills-entry-modern.oWckgtZS.worker.js"];
      var styles = ["/cdn/shopifycloud/checkout-web/assets/c1/assets/app.DzgRLp2z.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPayExternalAppContext.PQOzdEj1.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/getNormalizedPaymentMethodName.DWyYIMpE.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/OnePage.RWWzwUS2.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/DeliveryTransition.BbEi6fhy.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/StoreCreditRedemptionErrorBanner.DlkKDmBG.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPaySessionTokenStorage.CqVkJv9Z.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useOnePageFormSubmit.RkI_m_c8.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useGeneralPaymentErrorMessage.BrcQzLuH.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useShopPayProgressIntercepts.CIy8uDiZ.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Choice.HiYlaz_E.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/EmptyState.BEvzDDvy.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ChangeCompanyLocationLink.uqpm88mq.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Section.CU18S7Ap.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentLine.7870thps.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Switch.Dq_6Ius6.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentIcon.CLVwzp6i.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/progressiveShippingRatesLoading.LcqrKXE1.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/BillingAddressForm.BdwN7V1K.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PhoneField.DN6CUyst.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Middot.D7Ujmshx.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/EstimatedDeliveryContent.CGkrPwWj.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/PaymentButtons.CuS5ve3d.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/usePostPurchase.uv-X4L1-.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/NoAddressLocationFullDetour.CpFaJIpx.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Checkbox.RMAxlIo4.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/useSandboxTelemetry.CnR7qNLY.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/ShippingMethodSelector.B0hio2RO.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/SubscriptionPriceBreakdown.vTcdVGq4.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/StackedMerchandisePreview.D6OuIVjc.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/RuntimeExtension.DWkDBM73.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/AnnouncementRuntimeExtensions.D-e_Kz0B.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/QRCode.BZ_m5G5a.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/NumberField.CRpcZnVJ.css","/cdn/shopifycloud/checkout-web/assets/c1/assets/Sheet.BiQjEGaX.css"];
      var fontPreconnectUrls = [];
      var fontPrefetchUrls = [];
      var imgPrefetchUrls = [];

      function preconnect(url, callback) {
        var link = document.createElement('link');
        link.rel = 'dns-prefetch preconnect';
        link.href = url;
        link.crossOrigin = '';
        link.onload = link.onerror = callback;
        document.head.appendChild(link);
      }

      function preconnectAssets() {
        var resources = preconnectOrigins.concat(fontPreconnectUrls);
        var index = 0;
        (function next() {
          var res = resources[index++];
          if (res) preconnect(res, next);
        })();
      }

      function prefetch(url, as, callback) {
        var link = document.createElement('link');
        if (link.relList.supports('prefetch')) {
          link.rel = 'prefetch';
          link.fetchPriority = 'low';
          link.as = as;
          if (as === 'font') link.type = 'font/woff2';
          link.href = url;
          link.crossOrigin = '';
          link.onload = link.onerror = callback;
          document.head.appendChild(link);
        } else {
          var xhr = new XMLHttpRequest();
          xhr.open('GET', url, true);
          xhr.onloadend = callback;
          xhr.send();
        }
      }

      function prefetchAssets() {
        var resources = [].concat(
          scripts.map(function(url) { return [url, 'script']; }),
          styles.map(function(url) { return [url, 'style']; }),
          fontPrefetchUrls.map(function(url) { return [url, 'font']; }),
          imgPrefetchUrls.map(function(url) { return [url, 'image']; })
        );
        var index = 0;
        function run() {
          var res = resources[index++];
          if (res) prefetch(res[0], res[1], next);
        }
        var next = (self.requestIdleCallback || setTimeout).bind(self, run);
        next();
      }

      function onLoaded() {
        try {
          if (parseFloat(navigator.connection.effectiveType) > 2 && !navigator.connection.saveData) {
            preconnectAssets();
            prefetchAssets();
          }
        } catch (e) {}
      }

      if (document.readyState === 'complete') {
        onLoaded();
      } else {
        addEventListener('load', onLoaded);
      }
    })();
  